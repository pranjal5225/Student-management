//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package employee.management.system;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class UpdateEmployee extends JFrame implements ActionListener {
    JTextField tfeducation;
    JTextField tffname;
    JTextField tfaddress;
    JTextField tfphone;
    JTextField tfaadhar;
    JTextField tfemail;
    JTextField tfsalary;
    JTextField tfdesignation;
    JLabel lblempId;
    JButton add;
    JButton back;
    String empId;

    UpdateEmployee(String empId) {
        this.empId = empId;
        this.getContentPane().setBackground(Color.WHITE);
        this.setLayout((LayoutManager)null);
        JLabel heading = new JLabel("Update Employee Detail");
        heading.setBounds(320, 30, 500, 50);
        heading.setFont(new Font("SAN_SERIF", 1, 25));
        this.add(heading);
        JLabel labelname = new JLabel("Name");
        labelname.setBounds(50, 150, 150, 30);
        labelname.setFont(new Font("serif", 0, 20));
        this.add(labelname);
        JLabel lblname = new JLabel();
        lblname.setBounds(200, 150, 150, 30);
        this.add(lblname);
        JLabel labelfname = new JLabel("Father's Name");
        labelfname.setBounds(400, 150, 150, 30);
        labelfname.setFont(new Font("serif", 0, 20));
        this.add(labelfname);
        this.tffname = new JTextField();
        this.tffname.setBounds(600, 150, 150, 30);
        this.add(this.tffname);
        JLabel labeldob = new JLabel("Date of Birth");
        labeldob.setBounds(50, 200, 150, 30);
        labeldob.setFont(new Font("serif", 0, 20));
        this.add(labeldob);
        JLabel lbldob = new JLabel();
        lbldob.setBounds(200, 200, 150, 30);
        this.add(lbldob);
        JLabel labelsalary = new JLabel("Salary");
        labelsalary.setBounds(400, 200, 150, 30);
        labelsalary.setFont(new Font("serif", 0, 20));
        this.add(labelsalary);
        this.tfsalary = new JTextField();
        this.tfsalary.setBounds(600, 200, 150, 30);
        this.add(this.tfsalary);
        JLabel labeladdress = new JLabel("Address");
        labeladdress.setBounds(50, 250, 150, 30);
        labeladdress.setFont(new Font("serif", 0, 20));
        this.add(labeladdress);
        this.tfaddress = new JTextField();
        this.tfaddress.setBounds(200, 250, 150, 30);
        this.add(this.tfaddress);
        JLabel labelphone = new JLabel("Phone");
        labelphone.setBounds(400, 250, 150, 30);
        labelphone.setFont(new Font("serif", 0, 20));
        this.add(labelphone);
        this.tfphone = new JTextField();
        this.tfphone.setBounds(600, 250, 150, 30);
        this.add(this.tfphone);
        JLabel labelemail = new JLabel("Email");
        labelemail.setBounds(50, 300, 150, 30);
        labelemail.setFont(new Font("serif", 0, 20));
        this.add(labelemail);
        this.tfemail = new JTextField();
        this.tfemail.setBounds(200, 300, 150, 30);
        this.add(this.tfemail);
        JLabel labeleducation = new JLabel("Higest Education");
        labeleducation.setBounds(400, 300, 150, 30);
        labeleducation.setFont(new Font("serif", 0, 20));
        this.add(labeleducation);
        this.tfeducation = new JTextField();
        this.tfeducation.setBounds(600, 300, 150, 30);
        this.add(this.tfeducation);
        JLabel labeldesignation = new JLabel("Designation");
        labeldesignation.setBounds(50, 350, 150, 30);
        labeldesignation.setFont(new Font("serif", 0, 20));
        this.add(labeldesignation);
        this.tfdesignation = new JTextField();
        this.tfdesignation.setBounds(200, 350, 150, 30);
        this.add(this.tfdesignation);
        JLabel labelaadhar = new JLabel("Aadhar Number");
        labelaadhar.setBounds(400, 350, 150, 30);
        labelaadhar.setFont(new Font("serif", 0, 20));
        this.add(labelaadhar);
        JLabel lblaadhar = new JLabel();
        lblaadhar.setBounds(600, 350, 150, 30);
        this.add(lblaadhar);
        JLabel labelempId = new JLabel("Employee id");
        labelempId.setBounds(50, 400, 150, 30);
        labelempId.setFont(new Font("serif", 0, 20));
        this.add(labelempId);
        this.lblempId = new JLabel();
        this.lblempId.setBounds(200, 400, 150, 30);
        this.lblempId.setFont(new Font("serif", 0, 20));
        this.add(this.lblempId);

        try {
            Conn c = new Conn();
            String query = "select * from employee where empId = '" + empId + "'";
            ResultSet rs = c.s.executeQuery(query);

            while(rs.next()) {
                lblname.setText(rs.getString("name"));
                this.tffname.setText(rs.getString("fname"));
                lbldob.setText(rs.getString("dob"));
                this.tfaddress.setText(rs.getString("address"));
                this.tfsalary.setText(rs.getString("salary"));
                this.tfphone.setText(rs.getString("phone"));
                this.tfemail.setText(rs.getString("email"));
                this.tfeducation.setText(rs.getString("education"));
                lblaadhar.setText(rs.getString("aadhar"));
                this.lblempId.setText(rs.getString("empId"));
                this.tfdesignation.setText(rs.getString("designation"));
            }
        } catch (Exception var20) {
            var20.printStackTrace();
        }

        this.add = new JButton("Update Details");
        this.add.setBounds(250, 550, 150, 40);
        this.add.addActionListener(this);
        this.add.setBackground(Color.BLACK);
        this.add.setForeground(Color.WHITE);
        this.add(this.add);
        this.back = new JButton("Back");
        this.back.setBounds(450, 550, 150, 40);
        this.back.addActionListener(this);
        this.back.setBackground(Color.BLACK);
        this.back.setForeground(Color.WHITE);
        this.add(this.back);
        this.setSize(900, 700);
        this.setLocation(300, 50);
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == this.add) {
            String fname = this.tffname.getText();
            String salary = this.tfsalary.getText();
            String address = this.tfaddress.getText();
            String phone = this.tfphone.getText();
            String email = this.tfemail.getText();
            String education = this.tfeducation.getText();
            String designation = this.tfdesignation.getText();

            try {
                Conn conn = new Conn();
                String query = "update employee set fname = '" + fname + "', salary = '" + salary + "', address = '" + address + "', phone = '" + phone + "', email =  '" + email + "', education = '" + education + "', designation = '" + designation + "' where empId = '" + this.empId + "'";
                conn.s.executeUpdate(query);
                JOptionPane.showMessageDialog((Component)null, "Details updated successfully");
                this.setVisible(false);
                new Home();
            } catch (Exception var11) {
                var11.printStackTrace();
            }
        } else {
            this.setVisible(false);
            new Home();
        }

    }

    public static void main(String[] args) {
        new UpdateEmployee("");
    }
}
